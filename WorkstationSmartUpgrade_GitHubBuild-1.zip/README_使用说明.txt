工位智能助手 1.0（源码工程）

当前版本包含：
1. Shizuku 运行状态检查
2. Shizuku 权限申请
3. Shell input tap 点击测试
4. Shell input swipe 拖动测试
5. 停止后续自动化任务的按钮

当前版本尚未包含：
- 游戏画面识别
- 花盆、饮水机、垃圾袋、工位门的识别
- 自动判断金币、升级条件及自动摆放策略
这些功能必须根据《别坐我工位》的实际游戏截图、分辨率和操作规则开发，不能用猜测坐标冒充完整自动化。

构建：
1. Windows 安装 Android Studio。
2. 解压本工程，在 Android Studio 选择 Open，打开 WorkstationSmartUpgrade 文件夹。
3. 等待 Gradle Sync。需要联网下载 Android Gradle Plugin、Kotlin 插件和 Shizuku API。
4. 连接手机，Build > Build APK(s)。
5. 安装 APK，先启动 Shizuku，再打开本应用，点击“连接 / 请求 Shizuku 授权”。
6. 授权后先不要在游戏里测试。先用安全界面验证点击和拖动坐标，避免误触支付或删除操作。

重要：
- 不使用无障碍服务。
- Shizuku 必须保持运行。
- 示例触摸坐标按常见 1080 宽屏写入，仅用于演示，需按实际设备调整。
- 本工程是可继续开发的基础源码，不是已经完成游戏识别的成品 APK。
